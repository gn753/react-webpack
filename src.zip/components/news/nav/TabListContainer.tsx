import { useNewsList } from "../hooks/useNewsList";
import React from "react";

const TabListContainer = () => {

  return <div></div>;
};

export default TabListContainer;
