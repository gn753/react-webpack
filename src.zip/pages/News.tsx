import React from "react";
// Personlized News Page

import NewsContainer from "@/components/news";

const News = () => {
  return <NewsContainer />;
};

export default News;
